<template>
    <div class="app-container">
        <el-form label-position="top" label-width="80px">
            
        </el-form>
    </div>
</template>
<script>
export default {
    data() {
        return {

        }
    },
    created() {

    },
    methods: {
        initData() {
            this.getData()
        },
        getData() {

        }
    }
}
</script>